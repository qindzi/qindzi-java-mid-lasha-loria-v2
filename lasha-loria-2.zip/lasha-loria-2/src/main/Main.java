package main;

import java.io.File;
import java.util.Scanner;

class MyThread extends Thread {
    @Override
    public void run() {
        while (true) {
            File file = new File("C:\\Users\\99555\\IdeaProjects\\lasha-loria-2\\src\\BTU_DOCUMENT");
            int fileCounter = 0;
            int sum = 0;
            File[] array = file.listFiles();
            for (File sub : array) {
                if (sub.isFile()) {
                    fileCounter++;
                } else {
                    System.out.println("0 files in directory!!");
                }
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
            System.out.println(fileCounter);
        }

    }
}

    public class Main {
        public static void main(String[] args) throws InterruptedException {


            MyThread t1 = new MyThread();
            t1.start();



            while (true) {
                Scanner scan = new Scanner(System.in);
                System.out.println("Enter search word in file: ");
                String word = scan.nextLine();

                File file = new File("C:\\Users\\99555\\IdeaProjects\\lasha-loria-2\\src\\BTU_DOCUMENT");
                File[] array = file.listFiles();
                for (File sub : array) {
                    if (sub.isFile()){
                        if (sub.getName().contains(word)) {
                            System.out.println(sub.getName());
                            Thread.sleep(300);
                        } else {
                            System.out.println("0 files found");
                            Thread.sleep(300);
                        }
                    }

                }
            }
        }
}

